public interface Beverage {
    String getCoffee();
    double cost();
    String getSize();
    void setSize(String size);
}
